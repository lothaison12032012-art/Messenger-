module.exports.config = { name: "uptime", version: "1.0.0", hasPermssion: 0, credits: "By Dev T.son", description: "Xem thời gian bot đã hoạt động", commandCategory: "Tiện ích", usages: "", cooldowns: 3 };
module.exports.run = async function ({ api, event }) {
  const total = Math.max(0, Math.floor(process.uptime()));
  const days = Math.floor(total / 86400), hours = Math.floor(total % 86400 / 3600), minutes = Math.floor(total % 3600 / 60), seconds = total % 60;
  const mem = process.memoryUsage();
  const mb = n => (n / 1024 / 1024).toFixed(1);
  const text = `⏱ THỜI GIAN HOẠT ĐỘNG\n\n• Uptime: ${days} ngày ${hours} giờ ${minutes} phút ${seconds} giây\n• RAM đang dùng: ${mb(mem.rss)} MB\n• Node.js: ${process.version}`;
  return api.sendMessage(text, event.threadID, event.messageID);
};
