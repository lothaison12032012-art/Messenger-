module.exports.config = { name: "botinfo", version: "1.0.0", hasPermssion: 0, credits: "By Dev T.son", description: "Thông tin tổng quan về bot", commandCategory: "Tiện ích", usages: "", cooldowns: 3 };
module.exports.run = async function ({ api, event }) {
  const cfg = global.config || {};
  const commands = global.client && global.client.commands;
  const count = commands && typeof commands.size === "number" ? commands.size : "Chưa xác định";
  const name = String(cfg.BOTNAME || "Messenger Bot").replace(/[\r\n]/g, " ").slice(0, 80);
  const version = String(cfg.version || "Chưa khai báo").replace(/[\r\n]/g, " ").slice(0, 40);
  const text = `🤖 THÔNG TIN BOT\n\n• Tên: ${name}\n• Phiên bản: ${version}\n• Tổng lệnh nạp: ${count}\n• Node.js: ${process.version}\n• Người phát triển: By Dev T.son`;
  return api.sendMessage(text, event.threadID, event.messageID);
};
