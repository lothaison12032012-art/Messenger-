module.exports.config = { name: "ping", version: "1.0.0", hasPermssion: 0, credits: "By Dev T.son", description: "Kiểm tra độ trễ phản hồi của bot", commandCategory: "Tiện ích", usages: "", cooldowns: 3 };
module.exports.run = async function ({ api, event }) {
  const started = Date.now();
  return api.sendMessage("🏓 Đang kiểm tra độ trễ...", event.threadID, (err, info) => {
    if (err || !info || !info.messageID) return;
    const elapsed = Date.now() - started;
    api.editMessage(`🏓 PONG\nĐộ trễ phản hồi: ${elapsed} ms\nTrạng thái: Đang hoạt động`, info.messageID, () => {});
  }, event.messageID);
};
