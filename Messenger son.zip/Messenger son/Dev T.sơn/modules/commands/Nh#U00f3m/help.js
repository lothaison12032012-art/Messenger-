this.config = {
    name: "help",
    version: "2.1.0",
    hasPermssion: 0,
    credits: "By Dev T.son",
    description: "Trợ giúp và danh sách lệnh",
    commandCategory: "Nhóm",
    usages: "[tên lệnh/all]",
    cooldowns: 0
};

this.languages = { vi: {}, en: {} };

this.run = async function ({ api, event, args }) {
    const { threadID, messageID, senderID } = event;
    const commands = global.client && global.client.commands;
    if (!commands || typeof commands.values !== "function") {
        return api.sendMessage("Không thể tải danh sách lệnh lúc này. Vui lòng thử lại sau.", threadID, undefined, messageID);
    }

    const threadData = global.data && global.data.threadData
        ? (global.data.threadData.get(threadID) || {})
        : {};
    const prefix = threadData.PREFIX || (global.config && global.config.PREFIX) || ".";
    const botName = (global.config && global.config.BOTNAME && String(global.config.BOTNAME).trim()) || "Messenger Bot";
    const version = (global.config && global.config.version) || "Chưa khai báo";
    const moment = require("moment-timezone");
    const now = moment.tz("Asia/Ho_Chi_Minh");
    const dayNames = {
        Sunday: "Chủ Nhật", Monday: "Thứ Hai", Tuesday: "Thứ Ba",
        Wednesday: "Thứ Tư", Thursday: "Thứ Năm", Friday: "Thứ Sáu",
        Saturday: "Thứ Bảy"
    };
    const day = dayNames[now.format("dddd")] || now.format("dddd");
    const time = now.format("HH:mm:ss | DD/MM/YYYY");
    const adminIDs = (global.config && Array.isArray(global.config.ADMINBOT))
        ? global.config.ADMINBOT.map(String)
        : [];
    const isAdmin = adminIDs.includes(String(senderID));
    const privateCategories = new Set(["ADMIN", "NO PREFIX", "QUẢN TRỊ VIÊN", "QUAN TRI VIEN"]);

    const allCommands = Array.from(commands.values()).filter(cmd => cmd && cmd.config && cmd.config.name);
    const visibleCommands = allCommands.filter(cmd => {
        const category = String(cmd.config.commandCategory || "Khác").trim().toLocaleUpperCase("vi");
        return isAdmin || !privateCategories.has(category);
    });
    const query = Array.isArray(args) ? String(args[0] || "").trim().toLocaleLowerCase("vi") : String(args || "").trim().toLocaleLowerCase("vi");

    const clean = value => String(value == null ? "" : value).replace(/\s+/g, " ").trim();
    const categoryMap = new Map();
    for (const command of visibleCommands) {
        const cfg = command.config;
        const category = clean(cfg.commandCategory) || "Khác";
        if (!categoryMap.has(category)) categoryMap.set(category, []);
        categoryMap.get(category).push(cfg);
    }

    const categoryOrder = Array.from(categoryMap.keys()).sort((a, b) => a.localeCompare(b, "vi"));
    const header = [
        "╭━━━━━━━━━━━━━━━━━━━━━━━━╮",
        "┃       MESSENGER BOT       ┃",
        "╰━━━━━━━━━━━━━━━━━━━━━━━━╯",
        `👤 Quản lý: ${(global.config && (global.config.ADMIN_NAME || global.config.AMDIN_NAME)) || "Thái Sơn"}`,
        `🤖 Bot: ${botName}`,
        `⚙️ Phiên bản: ${version}`,
        `📚 Tổng lệnh hiển thị: ${visibleCommands.length}`,
        `📅 ${day} • ${time}`,
        "━━━━━━━━━━━━━━━━━━━━━━━━━━"
    ].join("\n");

    const sendText = async (text) => {
        const maxLength = 3000;
        const chunks = [];
        let current = "";
        for (const line of String(text).split("\n")) {
            if (current && `${current}\n${line}`.length > maxLength) {
                chunks.push(current);
                current = line;
            } else {
                current = current ? `${current}\n${line}` : line;
            }
            while (current.length > maxLength) {
                chunks.push(current.slice(0, maxLength));
                current = current.slice(maxLength);
            }
        }
        if (current) chunks.push(current);
        for (let i = 0; i < chunks.length; i++) {
            await new Promise(resolve => {
                const callback = () => resolve();
                try {
                    if (i === 0) api.sendMessage(chunks[i], threadID, callback, messageID);
                    else api.sendMessage(chunks[i], threadID, callback);
                } catch (error) {
                    console.error("[menu] sendMessage error:", error);
                    resolve();
                }
            });
        }
    };

    if (query === "all") {
        let index = 1;
        const sections = categoryOrder.map(category => {
            const list = categoryMap.get(category).sort((a, b) =>
                String(a.name).localeCompare(String(b.name), "vi")
            );
            const lines = list.map(cfg =>
                `${String(index++).padStart(3, "0")}. ${prefix}${cfg.name} — ${clean(cfg.description) || "Chưa có mô tả"}`
            );
            return `【 ${category.toLocaleUpperCase("vi")} · ${list.length} lệnh 】\n${lines.join("\n")}`;
        });
        await sendText(`${header}\n\n${sections.join("\n\n")}\n\n━━━━━━━━━━━━━━━━━━━━━━━━━━\nDùng ${prefix}menu <tên lệnh> để xem chi tiết.`);
        return;
    }

    if (query) {
        const command = visibleCommands.find(cmd =>
            String(cmd.config.name).toLocaleLowerCase("vi") === query
        );
        if (!command) {
            const names = visibleCommands.map(cmd => String(cmd.config.name));
            let suggestion = "";
            try {
                const similarity = require("string-similarity");
                const match = similarity.findBestMatch(query, names);
                if (match.bestMatch && match.bestMatch.rating >= 0.45) {
                    suggestion = `\nGợi ý: ${prefix}${match.bestMatch.target}`;
                }
            } catch (_) {}
            return api.sendMessage(`Không tìm thấy lệnh "${query}".${suggestion}\nDùng ${prefix}menu để xem danh mục.`, threadID, undefined, messageID);
        }

        const cfg = command.config;
        const permission = Number(cfg.hasPermssion || 0);
        const permissionText = permission === 0 ? "Thành viên" :
            permission === 1 ? "Quản trị viên nhóm" :
            permission === 2 ? "Admin Bot" : "Quyền đặc biệt";
        const detail = [
            "╭━━━━━━━━━━━━━━━━━━━━━━━━━━╮",
            "┃        CHI TIẾT LỆNH        ┃",
            "╰━━━━━━━━━━━━━━━━━━━━━━━━━━╯",
            `⌘ Lệnh: ${prefix}${cfg.name}`,
            `▸ Mô tả: ${clean(cfg.description) || "Chưa có mô tả"}`,
            `▸ Danh mục: ${clean(cfg.commandCategory) || "Khác"}`,
            `▸ Quyền: ${permissionText}`,
            `▸ Cách dùng: ${(prefix + cfg.name + " " + clean(cfg.usages)).trim()}`,
            `▸ Phiên bản: ${cfg.version || "Chưa khai báo"}`,
            `▸ Cooldown: ${cfg.cooldowns ?? 0}s`,
            `▸ Credit: ${cfg.credits || "By Dev T.son"}`,
            "━━━━━━━━━━━━━━━━━━━━━━━━━━"
        ].join("\n");
        return api.sendMessage(detail, threadID, undefined, messageID);
    }

    const sections = categoryOrder.map(category => {
        const list = categoryMap.get(category)
            .map(cfg => String(cfg.name))
            .sort((a, b) => a.localeCompare(b, "vi"));
        return `╭─〔 ${category.toLocaleUpperCase("vi")} · ${list.length} lệnh 〕\n│ ${list.join("  •  ")}\n╰──────────────────────────`;
    });
    const footer = [
        "━━━━━━━━━━━━━━━━━━━━━━━━━━",
        `📂 Danh mục: ${categoryOrder.length}`,
        `🔎 ${prefix}menu <tên lệnh>  •  Xem chi tiết`,
        `📜 ${prefix}menu all  •  Toàn bộ lệnh + mô tả`,
        `ℹ️ ${prefix}help  •  Trợ giúp`
    ].join("\n");
    await sendText(`${header}\n\n${sections.join("\n\n")}\n\n${footer}`);
};
