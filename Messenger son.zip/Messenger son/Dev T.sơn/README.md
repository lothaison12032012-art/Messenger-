# File mình share thuộc dạng ngon ở thời điểm hiện tại. Treo mượt không lỗi nên hãy giữ nguyên credit giúp mình nhé. 🌸
# Lưu ý: Đây là bản vá lỗi đầu tiên nên chưa có phiên bản dành cho hosting ! Mình sẽ update dần.
## Nhớ hãy fork (remix) đúng nguồn (@khoi0603k) tránh lỗi ✔

### Liên hệ mình qua:
- Facebook🪐 : Lương Trường Khôi
- Telegram🎶 : TrKhoi_Media
```
                  .----.
      .---------. | == |
      |.-"""""-.| |----|
      ||       || | == |
      ||       || |----|
      |'-.....-'| |::::|
      `"")---(""` |___.|
     /:::::::::::\" _  "
    /:::=======:::\`\`\
    `"""""""""""""`  '-'
```
# Cách sử dụng file:
## Bước 1:
- Vào  ``shell`` nhập ``npm install``
- Chờ nó tải xong
## Bước 2:
- Thêm appstate vào ``appstate.json``
- Sửa ``config.json`` và nhớ thêm uid bạn vào ``NDH``
- Nếu là iphone thì truy câp ``https://By Dev T.son.github.io/login`` để lấy appstate
## Bước 3: 
- Ấn Run để chạy bot và tận hưởng

# Lưu ý khi sử dụng:
- Giữ nguyên credit, không sửa linh tinh tránh lỗi
- Thắc mắc gì liên hệ qua Facebook mình

## Thiết lập trước khi chạy

- `appstate.json` trong bản này là placeholder JSON rỗng (`[]`) vì tệp nguồn không chứa AppState hợp lệ. Hãy đăng nhập theo quy trình của project để tạo AppState hợp lệ trước khi chạy bot.
- Không chia sẻ AppState hoặc access token; nếu token thật đã bị lộ, hãy thu hồi/đổi token.


## Lệnh tiện ích bổ sung
- `.ping`: đo thời gian phản hồi của bot.
- `.uptime`: xem thời gian hoạt động và mức RAM.
- `.botinfo`: xem thông tin cấu hình công khai của bot.
- `.tagall [nội dung]`: thay thế tên lệnh cũ `ping` dùng để tag thành viên.

Bộ giới hạn chống gọi lệnh liên tục chạy trong bộ nhớ, giới hạn 7 lệnh/10 giây theo người dùng và nhóm; tự hết hạn sau 10 giây và miễn trừ ADMINBOT. Đây không phải hệ thống chống spam tin nhắn tổng quát và trạng thái được đặt lại khi khởi động lại.
